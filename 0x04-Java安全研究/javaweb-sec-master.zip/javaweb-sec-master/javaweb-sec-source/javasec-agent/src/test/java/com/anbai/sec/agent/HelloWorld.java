package com.anbai.sec.agent;

/**
 * Creator: yz
 * Date: 2020/1/2
 */
public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World...");
	}

}

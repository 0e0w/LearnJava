package com.anbai.sec.vuls.commons;

/**
 * 常量在此定义
 *
 * @author yz
 */
public class Constants {

	public static final String SESSION_USER = "SESSION_USER";

}
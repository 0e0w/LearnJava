//package com.anbai.sec.cmd;
//
///**
// * 本地命令执行类
// * Creator: yz
// * Date: 2019/12/6
// */
//public class CommandExecution {
//
//	public static native String exec(String cmd);
//
//}

//package com.anbai.sec.classloader;
//
///**
// * Creator: yz
// * Date: 2019/12/17
// */
//public class TestHelloWorld {
//
//	public String hello() {
//		return "Hello World~";
//	}
//
//}
# Tomcat GetShell

这里我们指的 GetShell 方法为使用管理后台部署应用的方式。



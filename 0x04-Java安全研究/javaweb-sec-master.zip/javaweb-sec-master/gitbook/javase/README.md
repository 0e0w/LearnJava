# Java SE

Java平台共分为三个主要版本`Java SE`(`Java Platform, Standard Edition`-Java平台标准版)、`Java EE`(`Java Platform Enterprise Edition`-Java平台企业版)、和`Java ME`(`Java Platform, Micro Edition`-Java平台微型版)。

`Java SE`是JDK自带的标准API，内容涉及范围甚广，知识体系更是环环相扣浩瀚无边。没有基础,何来进阶！本章节整理了一些`Java SE`基础部分与`Java SE`安全相关的基础知识供初学者学习进阶。
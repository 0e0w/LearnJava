module.exports = {
	'&#x278a;': '<span class="token entity" title="&#x278a;">&amp;#x278a;</span>',
	'&#182;': '<span class="token entity" title="&#182;">&amp;#182;</span>'
};
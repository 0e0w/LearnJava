<template>
  <div>
    <div class="row">
      <div class="panel col-12">
        <h1 class="panel__title--border">任务基本信息</h1>
        <div class="panel__body">
          <table class="table">
            <tbody>
              <tr>
                <td>资产名称</td>
                <td>文思海辉金信</td>
                <td>资产等级</td>
                <td>重要</td>
              </tr>
              <tr>
                <td>子资产数</td>
                <td>100</td>
                <td>资产任务数</td>
                <td>10</td>
              </tr>
              <tr>
                <td>未处理漏洞数</td>
                <td>1</td>
                <td>可导出报告数</td>
                <td>15</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="panel col-12">
        <h1 class="panel__title--border">资产信息</h1>
        <div class="panel__body">测试</div>
      </div>
    </div>
    <div class="row">
      <div class="panel col-12">
        <h1 class="panel__title--border">漏洞信息</h1>
        <div class="panel__body">测试</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {

  name: 'taskInfoPage',

  data () {
    return {
    }
  },

  methods: {}
}

</script>
<style lang='scss' scoped>
</style>

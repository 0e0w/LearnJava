<template>
  <div class="panel">
    测试
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  },

  methods: {},

  created () { }
}

</script>
<style scoped>
</style>

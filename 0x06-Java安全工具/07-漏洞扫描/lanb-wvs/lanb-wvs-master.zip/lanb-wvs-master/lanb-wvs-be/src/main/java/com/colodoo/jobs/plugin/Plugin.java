package com.colodoo.jobs.plugin;

import java.util.Map;

public interface Plugin {

    Map execute(Map map);

}

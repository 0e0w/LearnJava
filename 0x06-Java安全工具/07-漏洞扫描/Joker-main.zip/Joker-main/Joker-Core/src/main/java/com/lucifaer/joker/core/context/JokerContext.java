package com.lucifaer.joker.core.context;

/**
 * @author Lucifaer
 * @version 1.0.0.RELEASE
 * @since 2020/11/18
 */
public class JokerContext {
}

package com.lucifaer.network.client;

/**
 * @author Lucifaer
 * @version 1.0.0.RELEASE
 * @since 2020/11/18
 */
public interface Client {
//  获取client名称
    String getClientName();
//  运行client
    void run();
}

# 漏洞发现平台

### 前端项目依赖
* Vue
* axios
* element-ui


### 后端项目依赖

* jdk 8
* Springboot
* Mybatis Plus
* Shiro
* lombok
* redis
* hibernate validatior
* jwt



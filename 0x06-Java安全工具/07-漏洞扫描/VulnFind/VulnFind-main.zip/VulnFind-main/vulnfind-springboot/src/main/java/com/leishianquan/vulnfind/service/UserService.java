package com.leishianquan.vulnfind.service;

import com.leishianquan.vulnfind.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author txf
 * @since 2021-02-23
 */
public interface UserService extends IService<User> {

}

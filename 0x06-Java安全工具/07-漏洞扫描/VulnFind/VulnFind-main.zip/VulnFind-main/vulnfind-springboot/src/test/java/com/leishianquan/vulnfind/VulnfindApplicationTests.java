package com.leishianquan.vulnfind;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VulnfindApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.sqldd;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Env1ApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.sqldd.fuzzingWaf.utils;

public class SequenceKeywordBypass {
}

package com.sqldd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Env1Application {

    public static void main(String[] args) {
        SpringApplication.run(Env1Application.class, args);
    }

}

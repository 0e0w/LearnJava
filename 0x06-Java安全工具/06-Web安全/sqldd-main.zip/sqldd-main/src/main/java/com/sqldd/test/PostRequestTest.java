package com.sqldd.test;

import com.sqldd.crawler.MyRequestSet;

public class PostRequestTest {
    public static void main(String[] args) {
        MyRequestSet myRequestSet = new MyRequestSet();
        //myRequestSet.postMethod(, )
    }
}

package BrianW.AKA.BigChan.Tools;

public class Global {
	public static BrianW.AKA.BigChan.GUI.PowerTab PowerTab;
	public static String configFile = "powerscanner.conf.ini";
	public static String[] fileExt = new String[]{"doc", };
	public static Config config;
}


process.env.VUE_APP_REST_API_BASE_URL = process.env.REST_API_BASE_URL


module.exports = {
  // config
  runtimeCompiler: true
}
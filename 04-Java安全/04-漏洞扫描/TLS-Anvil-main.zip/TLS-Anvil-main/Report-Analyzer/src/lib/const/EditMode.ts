export enum EditMode {
  selected = "selected",
  allAll = "allAll",
  specified = "specified",
  allAvailable = "allAvailable"
}
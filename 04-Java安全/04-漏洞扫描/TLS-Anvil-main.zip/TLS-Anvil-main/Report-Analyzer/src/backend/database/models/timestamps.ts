
export interface ITimestamp {
  createdAt: Date,
  updatedAt: Date
}

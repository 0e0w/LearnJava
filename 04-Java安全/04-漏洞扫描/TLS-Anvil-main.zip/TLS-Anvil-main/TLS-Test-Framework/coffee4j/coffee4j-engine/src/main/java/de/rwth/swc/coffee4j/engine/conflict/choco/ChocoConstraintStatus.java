package de.rwth.swc.coffee4j.engine.conflict.choco;

enum ChocoConstraintStatus {
    POSTED, UNPOSTED
}

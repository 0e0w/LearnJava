package de.rwth.swc.coffee4j.engine.conflict;

public class UnknownConflictExplanation implements ConflictExplanation {
}

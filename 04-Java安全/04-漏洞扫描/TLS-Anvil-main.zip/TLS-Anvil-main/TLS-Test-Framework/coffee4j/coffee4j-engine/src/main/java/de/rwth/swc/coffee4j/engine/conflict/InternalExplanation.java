package de.rwth.swc.coffee4j.engine.conflict;

public interface InternalExplanation {
}

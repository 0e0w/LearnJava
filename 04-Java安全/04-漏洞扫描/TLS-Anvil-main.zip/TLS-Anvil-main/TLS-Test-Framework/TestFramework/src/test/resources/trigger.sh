#!/bin/bash

openssl s_client localhost:443
